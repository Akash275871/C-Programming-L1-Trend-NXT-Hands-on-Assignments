﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TopGearCSharpProgramming_L1
{
    #region Assingment1
    //Assingment1
    class Program
    {
        int Id;
        string Name;
        string Address;
        double Salary;

        public void ShowDetails(UInt32 id, string name, double salary)//Method overloading
        {

            if (id == objemp.EmployeeId)
            {
                Console.WriteLine("Same employee Id entered");

            }
            else
            {
                Console.WriteLine("Entered Employee Id is: {0}", (id + 1));
                Console.WriteLine("Entered Employee Name is: {0}", name);
                Console.WriteLine("Entered Employee Salary is: {0}", salary);
                Console.ReadLine();

            }


        }
        Employee objemp = new Employee();
        Manager objManager = new Manager();
        //static void Main(string[] args)
        //{

        //    Employee objemp = new Employee();
        //    Manager objManager = new Manager();

        //    objemp.ShowDetails();
        //    objManager.ShowDetails();
        //    objManager.ShowSalary();
        //    objManager.ShowTotalSalary();

        //    Console.WriteLine("Enter employee ID");
        //    UInt32 id = Convert.ToUInt32(Console.ReadLine().ToString());
        //    Console.WriteLine(id);

        //    Program objProgram = new Program();
        //    objProgram.ShowDetails(id, objemp.EmpName, objManager.TotalSalary);



        //    Console.ReadLine();
        //}
    }

    class Employee
    {
        private int empId = 1000;
        private string Name;

        protected double Salary;

        public int EmployeeId
        {
            get { return empId; }
            set { empId = value; }
        }
        public string EmpName
        {
            get { return Name; }
            set { Name = value; }
        }
        public double EmpSalary
        {
            get { return Salary; }
            set { Salary = value; }
        }

        public Employee()
        {

        }
        public Employee(int empid, string name, double salary)
        {

        }

        public void ShowDetails()
        {
            empId = 1000;
            Name = "Akash Srivastava";
            Salary = 7000000;

            Console.WriteLine("EmployeeID: {0}", empId);
            Console.WriteLine("EmployeeName: {0}", Name);
            Console.WriteLine("EmployeeSalary: {0}", Salary);
        }


    }

    class Manager : Employee
    {
        Employee emp = new Employee();
        private int TravelAllowance;

        //  private int _TravelAllowance;

        public int TrvlAllwnce
        {
            get { return TravelAllowance; }
            set { TravelAllowance = value; }
        }

        public double TotalSalary;

        public Manager()
        {

        }

        public Manager(int EmpId, int Travelallowance, string Name, double Salry)
        { }

        public void ShowSalary()
        {
            EmpSalary = 5000000;
            Console.WriteLine("Employee Salary is {0}", EmpSalary);
        }

        public void ShowTotalSalary()
        {
            TravelAllowance = 300000;
            TotalSalary = TravelAllowance + EmpSalary;
            Console.WriteLine("Employee Total Salary is {0} ", TotalSalary);

        }
    }

    #endregion Assingment1
    //-----------------------------------------------------------------------------------------------------------------------------

    #region Assingment2
    //Assingment 2

    class Assingment2
    {


        //static void Main()
        //{
        //    int count1 = 0;
        //    int count2 = 0;
        //    string sFirstString = "";
        //    string sSecondString = "";
        //    Console.WriteLine("Please input First String");
        //    Assingment2 asng2 = new Assingment2();
        //    sFirstString = Console.ReadLine();
        //    Console.WriteLine("String Entered by you is: {0}\n", sFirstString);

        //    Console.WriteLine("\nPlease input Second String");
        //    sSecondString = Console.ReadLine();
        //    Console.WriteLine("String Entered by you is: {0}\n", sSecondString);
        //    for (int i = 0; i < sFirstString.Length; i++)
        //    {
        //        if (sFirstString[i] == 'a' || sFirstString[i] == 'A')
        //        {
        //            count1++;

        //        }



        //    }
        //    for (int i = 0; i < sSecondString.Length; i++)
        //    {
        //        if (sSecondString[i] == 'a' || sSecondString[i] == 'A')
        //        {
        //            count2++;
        //        }

        //    }
        //    Console.WriteLine("\nNumber of occurance of A in FistString is: {0}\n", count1);
        //    Console.WriteLine("\nNumber of occurance of A in SecondString is: {0}\n", count2);


        //    Console.WriteLine("\nFirst String after manipulation is: {0}\n", asng2.TruncateString(sFirstString));

        //    Console.WriteLine("\nFSecond String after manipulation is: {0}\n", asng2.TruncateString(sSecondString));

        //    Console.WriteLine("\nFirst String after Upper Case convertion:   {0}\n", sFirstString.ToUpper());
        //    Console.WriteLine("\nSecond String after Upper Case convertion: {0}\n", sSecondString.ToUpper());

        //    //  asng2.Concat(sFirstString, sSecondString);
        //    Console.WriteLine("\n String after concatination is: {0}\n", asng2.Concat(sFirstString, sSecondString));

        //    //Console.WriteLine("StringBuilder operation's Output is: {0}\n", asng2.StringBuiderExample(sFirstString));
        //    asng2.StringBuiderExample(sFirstString);
        //    Console.ReadKey();
        //}

        public string TruncateString(string Result1)
        {
            string str = "";
            if (Result1.Contains('a'))
            {
                str = Result1.Replace('a', 'A');

            }
            return Regex.Replace(str, "A", "@");
        }
        public string Concat(string str1, string str2)
        {
            //if (str1.Length>0 &&)
            //{

            //}
            return str1 + str2;
        }

        public string StringBuiderExample(string res)
        {
            StringBuilder str = new StringBuilder(res, 100);
            str.Append(" Akash");
            Console.WriteLine("String after Append operation is: {0}", str);
            str.Insert(1, " Akash ");
            Console.WriteLine("String after Insert operation is: {0}", str);
            str.Replace("Akash", "Srivastava");
            Console.WriteLine("String after Replace operation is: {0}", str);

            StringBuilder sb = new StringBuilder(res, res.Length);
            if (sb.Length > 7)
            {
                sb.Remove(6, 7);
            }
            else
            {
                Console.WriteLine("Cannot perform Remove operation as the string provided does not meets the lenght");
            }
            return res;

        }



    }

    #endregion Assingment2

    //------------------------------------------------------------------------------------------------------------------------------
    #region Assingment3

    //Assingment 3
    class Time
    {
        int m_iHours;
        int m_iMinutes;
        int m_iSeconds;
        string m_itotalTime;
        public Time()
        {
            m_iHours = 00;
            m_iMinutes = 00;
            m_iSeconds = 00;
            Console.WriteLine("Initial Time is: 00:00:00");


        }
        public Time(int iMinutes)
        {
            TimeSpan time = TimeSpan.FromMinutes(iMinutes);
            //  m_iHours = iMinutes / 60;
            // m_iMinutes = iMinutes % 60;
            //  var time = TimeSpan.FromMinutes(iMinutes);
            Console.WriteLine("Hour {0:00}: Minute {1:00}", (int)time.TotalHours, (int)time.Minutes);

        }
        public Time(long iSeconds)
        {
            TimeSpan time = TimeSpan.FromSeconds(iSeconds);
            Console.WriteLine("Hour {0:00}: Minute {1:00} : Second {2:00}", (int)time.TotalHours, (int)time.Minutes, (int)time.Seconds);
        }

        //public static void Main()

        //{

        //    Console.WriteLine("Please Enter Minutes");

        //    int iMinute =Convert.ToInt16( Console.ReadLine());
        //    Time tm = new Time(iMinute);

        //    Console.WriteLine("Please Enter Seconds");

        //    long lSeconds =Convert.ToInt64(Console.ReadLine());

        //    // Time tmSec = new Time((long)10000000);
        //    Time tmSec = new Time(lSeconds);


        //    Console.ReadKey();


        //}
    }

    #endregion Assingment3
    //-------------------------------------------------------------------------------------------------------------------------------

    #region Assingment4
    //Assingment 4 

    class Assingment4
    {

        public int fnValidate(string a, string b, string c, string d)
        {
            int parsedA;
            int parsedB;
            int parsedC;
            int parsedD;
            if (int.TryParse(a, out parsedA) && int.TryParse(b, out parsedB) && int.TryParse(c, out parsedC) && int.TryParse(d, out parsedD))
            {
                Console.WriteLine("All input parameters are  of type integer");

                fnMaxMin(parsedA, parsedB, parsedC, parsedD);
                fnSumOfDigits(parsedA, parsedB, parsedC, parsedD);

                return 1;
            }
            else
            {
                Console.WriteLine("All input parameters are not of type integer hence cannot perform fnMaxMin,fnSumOfDigits  functions");
                return 0;
            }
        }


        public void fnMaxMin(int a, int b, int c, int d)
        {
            if (a > b && a > c && a > d)
            {
                Console.WriteLine("Maximum Value is {0}", a);
            }
            else if (b > a && b > c && b > d)
            {
                Console.WriteLine("Maximum Value is {0}", b);
            }
            else if (c > a && c > b && c > d)
            {
                Console.WriteLine("Maximum Value is {0}", c);
            }
            else if (d > a && d > b && d > c)
            {
                Console.WriteLine("Maximum Value is {0}", d);
            }

            if (a < b && a < c && a < d)
            {
                Console.WriteLine("Minimum Value is {0}", a);
            }
            else if (b < a && b < c && b < d)
            {
                Console.WriteLine("Minimum Value is {0}", b);
            }
            else if (c < a && c < b && c < d)
            {
                Console.WriteLine("Minimum Value is {0}", c);
            }
            else if (d < a && d < b && d < c)
            {
                Console.WriteLine("Minimum Value is {0}", d);
            }
            if (a == b && a == c && a == d)
            {
                Console.WriteLine("You have entered same value");
            }
        }
        int sumA, sumB, sumC, sumD, r, TotalSum = 0;

        public void fnSumOfDigits(int a, int b, int c, int d)
        {


            while (a != 0)
            {
                r = a % 10;
                a = a / 10;
                sumA = sumA + r;
            }
            Console.WriteLine(sumA);

            while (b != 0)
            {
                r = b % 10;
                b = b / 10;
                sumB = sumB + r;

            }
            Console.WriteLine(sumB);

            while (c != 0)
            {
                r = c % 10;
                c = c / 10;
                sumC = sumC + r;

            }
            Console.WriteLine(sumC);

            while (d != 0)
            {
                r = d % 10;
                d = d / 10;
                sumD = sumD + r;

            }
            Console.WriteLine(sumD);
            TotalSum = (sumA + sumB + sumC + sumD);

            Console.WriteLine("Sum of all the input parameter is: {0}", TotalSum);


        }

        //public static void Main()
        //{
        //    Console.WriteLine("Please enter any value for a");
        //    var a = Console.ReadLine();
        //    Console.WriteLine("Please enter any value for b");
        //    var b = Console.ReadLine();
        //    Console.WriteLine("Please enter any value for c");
        //    var c = Console.ReadLine();
        //    Console.WriteLine("Please enter any value for d");
        //    var d = Console.ReadLine();

        //    Assingment4 asng4 = new Assingment4();
        //    asng4.fnValidate(a, b, c, d);
        //    Console.ReadLine();
        //}
        //}

    }
    #endregion Assingment4



    #region Topic4:Modifiers

    #region Assingment1
    public class AirTicket
    {
        public string FlightNumber = "A1004";
        public DateTime date = System.DateTime.Now;
        //  public Time tTime;
        public string Destination = "CCU";
    }

    public class ConfirmedTicket : AirTicket
    {
        public string SeatNumber = "A1";
    }

    public class RequestedTicket : AirTicket
    {
        public string Status = "Confirmed";
    }

    //public static void Main()
    //{
    //    ConfirmedTicket ct = new ConfirmedTicket();
    //    Console.WriteLine("Flight Number is: {0}", ct.FlightNumber);

    //    Console.WriteLine("Ticket Booking Time is: {0}", ct.date);

    //    Console.WriteLine("Destination: {0}", ct.Destination);
    //    Console.WriteLine("Seat Number is: {0}", ct.SeatNumber);



    //    RequestedTicket rt = new RequestedTicket();
    //    Console.WriteLine("Current Status of ticket is: {0}", rt.Status);

    //    Console.ReadLine();

    //}

    #endregion Assingment1
    //--------------------------------------------------------------------------------------------------
    //Assingment 2
    #region Assingment2

    public class Employee1
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string code;

        public string Code
        {
            get { return code; }
            set { code = value; }
        }
        private string departmentName;

        public string DepartmentName
        {
            get { return departmentName; }
            set { departmentName = value; }
        }
        private string designation;

        public string Designation
        {
            get { return designation; }
            set { designation = value; }
        }

        Employee1(string name, string code, string departmentName, string designation)
        {
            this.code = code;
            this.name = name;
            this.departmentName = departmentName;
            this.designation = designation;
        }


        // Employee1 emp = new Employee1();

        //public static void Main()
        //{
        //    //string[] Employee= 
        //    List<string> emp1 = new List<string>();

        //    //for (int i = 0; i < 4; i++)
        //    //{
        //    //    emp1.Add(("AK275871", "Akash", "WT", "Sr. Project Engineer"));
        //    //}

        //    Console.WriteLine(string.Join(",", emp1));
        //    Console.ReadLine();
        //}


    }


    #endregion Assingment2






    #endregion Topic4: Modifiers



    #region Topic5

    #region Assignment 1

    #region Assingment1_a
    //to find for ‘N’ number of students whether they are ‘Pass’ or ‘Fail’. Suppose
    /// passing marks are 70. Take marks as input
    public class Assingment1_a
    {
        //static void Main()
        //{
        //    var TotalStudent = 0;
        //    int[] strudentMarks = new int[TotalStudent];
        //    string[] StudentName = new string[TotalStudent];

        //    Console.WriteLine("Enter the number of Students");
        //    TotalStudent = Convert.ToInt32(Console.ReadLine());
        //    if (TotalStudent > 0)
        //    {

        //        Console.WriteLine("\nEnter the Names of " + TotalStudent + " Student");
        //        for (int i = 0; i < TotalStudent; i++)
        //        {
        //            Console.Write(i + 1 + ": ");
        //            StudentName[i] = Console.ReadLine();

        //        }
        //        Console.WriteLine("\nEnter Marks Student for " + TotalStudent);
        //        for (int i = 0; i < TotalStudent; i++)
        //        {
        //            Console.Write(i + 1 + ": ");
        //            strudentMarks[i] = Convert.ToInt32(Console.ReadLine());

        //        }
        //        Console.WriteLine("\nPlease enter the Marks");
        //        var MarksEntered = Convert.ToInt32(Console.ReadLine());
        //        if (MarksEntered >= 70)
        //        {
        //            for (int i = 0; i < strudentMarks.Length; i++)
        //            {
        //                if (strudentMarks[i] >= 70)
        //                {
        //                    Console.WriteLine(StudentName[i] + "  is Pass");
        //                }
        //                else
        //                {
        //                    Console.WriteLine(StudentName[i] + "  is Fail");
        //                }
        //            }
        //        }
        //        else
        //        {
        //            Console.WriteLine("\nPassing Marks is 70");

        //        }
        //    }
        //    else
        //    {
        //        Console.WriteLine("\n Number of Students cannot be zero");
        //    }

        //    for (int i = 0; i < strudentMarks.Length; i++)
        //    {
        //        // strudentMarks[i];
        //    }
        //    Console.ReadLine();
        //}
    }

    #endregion

    #region Assingment1_b
    //to sort the elements of an array in ascending order.
    public class Assingmnet1_b
    {
        //public static void Main()
        //{
        //    Console.WriteLine("Enter the Size of an Array");

        //    int Size =Convert.ToInt16( Console.ReadLine());

        //    if (Size>0)
        //    {
        //        int[] arr = new int[Size];
        //        Console.WriteLine("Enter the value of an Array:");

        //        for (int i = 0; i < Size; i++)
        //        {
        //            arr[i] = Convert.ToInt16(Console.ReadLine());


        //        }

        //        Console.WriteLine("Non sorted Items in array are:");
        //        for (int i = 0; i < arr.Length; i++)
        //        {
        //            Console.WriteLine(arr[i]+ "\n");
        //        }
        //        Console.WriteLine("Sorted Items in array are:");
        //        Array.Sort(arr);

        //        foreach (var item in arr)
        //        {
        //            Console.WriteLine(item + "\n");
        //        }

        //    }
        //    else
        //    {
        //        Console.WriteLine("Array cannot be of zero size");
        //    }

        //    Console.ReadLine();

        //}
    }

    #endregion

    #region Assingment1_c
    //to implement two dimensional array.

    public class Assingngment1_c
    {
        //public static void Main()
        //{
        //    int[,] array2D = new int[4, 2] { { 1, 2 }, { 3, 4 }, { 5, 6 }, { 7, 8 } };
        //    int rowLength = array2D.GetLength(0);
        //    int colLength = array2D.GetLength(1);

        //    for (int i = 0; i < rowLength; i++)
        //    {
        //        for (int j = 0; j < colLength; j++)
        //        {
        //            Console.Write(string.Format("{0} ", array2D[i, j]));
        //        }
        //        Console.Write(Environment.NewLine + Environment.NewLine);
        //    }

        //    foreach (var item in array2D)
        //    {
        //        Console.Write(string.Format("{0} ", item));
        //    }

        //    Console.ReadLine();
        //}


    }


    #endregion

    #region Assingment1_d
    //to implement jagged array.
    class Assingment1_d
    {
        //static void Main(string[] args)  
        //{  
        //    // Declare the array of four elements:  
        //    int[][] jaggedArray = new int[4][];  
        //    // Initialize the elements:  
        //    jaggedArray[0] = new int[2] { 7, 9 };  
        //    jaggedArray[1] = new int[4] { 12, 42, 26, 38 };  
        //    jaggedArray[2] = new int[6] { 3, 5, 7, 9, 11, 13 };  
        //    jaggedArray[3] = new int[3] { 4, 6, 8 };  
        //    // Display the array elements:  
        //    for (int i = 0; i < jaggedArray.Length; i++)  
        //    {  
        //        System.Console.Write("Element({0}): ", i + 1);  
        //        for (int j = 0; j < jaggedArray[i].Length; j++)  
        //        {  
        //            System.Console.Write(jaggedArray[i][j] + "\t");  
        //        }  
        //        System.Console.WriteLine();  
        //    }  
        //    Console.ReadLine();  
        //}  
    }
    #endregion
    #endregion Assignment 1




    #region Assingment2

    public abstract class Instrument
    {
        public abstract void Play();

    }
    class Piano : Instrument
    {
        public override void Play()
        {
            Console.WriteLine("Piano is playing tan tan tan tan ");
        }

    }
    public class Flute : Instrument
    {
        public override void Play()
        {
            Console.WriteLine("Flute is playing toot toot toot toot");
        }


    }
    public class Guitar : Instrument
    {
        public override void Play()
        {
            Console.WriteLine("Guitar is playing tin tin tin");
        }
    }

    public class MainClass
    {
        //public static void Main()
        //{
        //    Instrument[] ins = new Instrument[10];
        //    for (int i = 0; i < 10; i++)
        //    {
        //        if (i == 1 || i == 5 || i == 9)
        //            ins[i] = new Piano();
        //        else if (i == 3 || i == 4 || i == 7)
        //            ins[i] = new Flute();
        //        else ins[i] = new Guitar();
        //        ins[i].Play();
        //        if (i == 1 || i == 5 || i == 9)
        //            Console.WriteLine("\nInstance Of Piano");

        //        else if (i == 3 || i == 4 || i == 7)
        //            Console.WriteLine("\nInstanceOf Flute");
        //        else Console.WriteLine("\nInstanceOf Guitar");
        //    }
        //    Console.ReadLine();
        //}
    }


    #endregion Assingment2


    #endregion Topic5


    #region Topic6


    #region Assingment 1

    class Division
    {
        float x, y;
        float result;


        public void Divide()
        {
            Console.WriteLine("Enter value of X");

            x = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter value of Y");

            y = Convert.ToInt32(Console.ReadLine());

            try
            {
                result = x / y;
                Console.WriteLine("\nResult of Division is: {0}", result);
            }
            catch (Exception)
            {
                Console.WriteLine("The division operation cannot be done as the divisor is 0");
            }
        }

        //public static void Main()
        // {
        //     Division div = new Division();
        //     div.Divide();

        //     Console.ReadLine();
        // }
    }



    #endregion Assingment 1


    #region Assingment 2

    public class A
    {
        public static void Main(string[] arguments)
        {
            string[] arg = Environment.GetCommandLineArgs();
            try
            {

                if (arg.Length > 0 /*&& arg.Length == 3*/)
                {
                    try
                    {
                        if (arg[1].Length == 0)
                        {
                            Console.WriteLine("Name is in the not in correct format");
                            // NameException("Name is in the not in correct format");

                        }
                        else
                        {
                            Console.WriteLine("Name entered by you is: {0}", arg[1].ToString());
                        }
                    }
                    catch (Exception a)
                    {

                        throw a;
                    }


                    if (arg[2].Length != 0)
                    {
                        int parsedA;
                        int.TryParse(arg[2], out parsedA);
                        try
                        {
                            if (parsedA != 0)
                            {
                                int a = Convert.ToInt32(arg[2].ToString());

                                if (parsedA >= 18 && parsedA < 60)
                                {
                                    Console.WriteLine("Age entered by you is : {0} which lies in between 18 to 60\n ", parsedA);
                                }
                                else
                                {
                                    Console.WriteLine("Age entered by you is not in correct range");
                                }
                            }
                            else
                            {
                                Console.WriteLine("You have not entered age in correct format");
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                    else
                    {
                        Console.WriteLine("You have not entered age\n");
                    }
                
                }
                else
                {
                    Console.WriteLine("Items in argument list is not in correct format\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n");
            }

            Console.ReadLine();
        }


    }

    #endregion Assingment 2


    #endregion


}







//} 








